from aiogram import types
from aiogram.dispatcher import FSMContext
from loader import *
from config import *
from data.functions.get_info import *
from keyboards.user_kb import *
from aiogram.dispatcher.filters.state import StatesGroup, State
from states.user_state import *
from aiogram.types import Message
import aiogram
from datetime import datetime, timedelta
from telethon.sync import TelegramClient
from telethon.tl.functions.messages import ReportRequest
from telethon.tl.types import (
    InputPeerChannel,
    InputReportReasonSpam,
    InputReportReasonViolence,
    InputReportReasonPornography,
    InputReportReasonChildAbuse,
    InputReportReasonIllegalDrugs,
    InputReportReasonPersonalDetails,
    InputReportReasonOther
)
import re
import os
import random
import asyncio
from pyrogram.errors import Unauthorized, FloodWait, RPCError
from pyrogram.raw.types import (
    InputPeerChannel,
    InputReportReasonSpam,
    InputReportReasonViolence,
    InputReportReasonPornography,
    InputReportReasonChildAbuse,
    InputReportReasonIllegalDrugs,
    InputReportReasonPersonalDetails,
    InputReportReasonOther
)
from pyrogram import Client
from pyrogram.raw.functions.messages import Report
from data.functions.adds import *
from data.functions.adds import *

def filtersnos(message_url):
    path = message_url[len("https://t.me/") :].split("/")
    if len(path) == 2:
        chat_username = path[0]
        message_id = int(path[1])
        return chat_username, message_id
    raise ValueError("Неверная ссылка!")


@dp.callback_query_handler(lambda call: call.data == 'prp')
async def tlt222prp(call: types.CallbackQuery):
    user_id = call.from_user.id
    issub = (await get_aktiv(user_id))[0]
    if issub == 'Отсутствует':
        await call.message.edit_caption(
            caption=f"<b>❌ Ваша подписка - отсутствует</b>",
            parse_mode='HTML',
            reply_markup=await nehvataet_kb()
        )
    else:
        await call.message.edit_caption(
            caption=f"<b>💎 Выбери причину репорта</b>",
            parse_mode='HTML',
            reply_markup=await prpreport()
        )


async def handle_session(session_file, chat_username, message_id, reason_str, successful_sessions, failed_sessions):
    client = None
    try:
        with open(f"jsessions/{session_file}", "r", encoding="utf-8") as f:
            session_data = json.load(f)
        client = Client(
            name=session_data["session_file"],
            api_id=session_data["app_id"],
            api_hash=session_data["app_hash"],
            phone_number=session_data["phone"],
            workdir="jsessions/"
        )
        await client.start()
        me = await client.get_me()
        if not me:
            pass
            await client.stop()
            failed_sessions.append(session_file)
            return {"success": False, "session_file": session_file}
        reason = InputReportReasonSpam() if reason_str.lower() == "spam" else InputReportReasonOther()
        await client.invoke(
            Report(
                peer=await client.resolve_peer(chat_username),
                id=[int(message_id)],
                reason=reason,
                message="This user is engaged in telegram spam mailings. Take action"
            )
        )
        await client.stop()
        print(f"Жалоба отправлена с сессии {session_file}")
        successful_sessions.append(session_file)
        return {"success": True, "session_file": session_file}
    except Exception as e:
        pass
        failed_sessions.append(session_file)
        return {"success": False, "session_file": session_file}
    finally:
        if client and client.is_connected:
            await client.stop()


async def process_complaint(user_id, message_url, reason_str):
    try:
        chat_username, message_id = filtersnos(message_url)
    except ValueError:
        print("Ошибка: Неверная ссылка!")
        return
    successful_sessions = []
    failed_sessions = []
    session_files = [f for f in os.listdir("jsessions/") if f.endswith(".json")]
    tasks = []
    for session_file in session_files:
        tasks.append(
            handle_session(session_file, chat_username, message_id, reason_str, successful_sessions, failed_sessions))

    try:
        results = await asyncio.wait_for(asyncio.gather(*tasks), timeout=10)
    except asyncio.TimeoutError:
        pass
        results = []

    successful_reports = len(successful_sessions)
    failed_reports = len(failed_sessions)

    report = f"""
<b>💎 Жалобы отправлены</b>

<b>✅ Метод:</b> <code>{reason_str.capitalize()}</code>
🔗<b> Ссылка:</b> <code>{message_url}</code>

👤<b> Репорты успешно отправлены!</b>
    """
    user = await bot.get_chat(user_id)
    user_name = user.username if user.username else " "
    await add_snos(user_id, reason_str, message_url)
    await bot.send_photo(
        chat_id=user_id,
        caption=f"{report}",
        photo=photo,
        parse_mode='HTML',
        reply_markup=await bbkprp()
    )
    message_text = f"""<b>💎 Новый репорт</b>\n<b>👤 ID:</b> @{user_name} | {user_id}\n<b>🚀 Метод:</b> {reason_str.capitalize()}\n<b>💎 Ссылки:</b> <a href="{message_url}">Перейти</a>
            """

    await bot.send_message(logs_id, message_text, parse_mode='HTML')


    if successful_reports > 0:
        pass
    else:
        pass

@dp.callback_query_handler(lambda callback_query: callback_query.data.startswith("prp"))
async def govnopartia(callback_query: types.CallbackQuery, state: FSMContext):
    user_id = callback_query.from_user.id
    issub = (await get_aktiv(user_id))[0]
    if issub == 'Отсутствует':
        await callback_query.message.edit_caption(
            caption=f"<b>❌ Ваша подписка - отсутствует</b>",
            parse_mode='HTML',
            reply_markup=await nehvataet_kb()
        )
    else:
        reason = callback_query.data.split(":")[1]
        await state.set_state(repomessagepyrogram.link)
        await state.update_data(reason_str=reason)
        await callback_query.message.edit_caption(
            "<b>🚀 Вы выбрали метод: Pyrogram\n💎 Введите ссылку на сообщение для репорта</b>",
            reply_markup=await cancelkb(), parse_mode='HTML'
        )

@dp.message_handler(state=repomessagepyrogram.link)
async def process_complaint_link(message: types.Message, state: FSMContext):
    user_id = message.from_user.id
    data = await state.get_data()
    reason_str = data.get('reason_str')
    message_url = message.text
    await bot.send_message(chat_id=user_id, text="<b>🚀 Отправляем репорты...</b>", parse_mode='HTML')
    await state.finish()
    await process_complaint(user_id, message_url, reason_str)

