
from aiogram import types
from aiogram.dispatcher import FSMContext
from loader import *
from config import *
from data.functions.get_info import *
from keyboards.user_kb import *
from aiogram.dispatcher.filters.state import StatesGroup, State
from states.user_state import *
from aiogram.types import Message
import aiogram
from datetime import datetime, timedelta
from telethon.sync import TelegramClient
from telethon.tl.functions.messages import ReportRequest
from telethon.tl.types import (
    InputPeerChannel,
    InputReportReasonSpam,
    InputReportReasonViolence,
    InputReportReasonPornography,
    InputReportReasonChildAbuse,
    InputReportReasonIllegalDrugs,
    InputReportReasonPersonalDetails,
    InputReportReasonOther
)
import re
import os
import random
import asyncio

@dp.callback_query_handler(lambda call: call.data == 'tlt')
async def tlt(call: types.CallbackQuery):
    user_id = call.from_user.id
    issub = (await get_aktiv(user_id))[0]
    if issub == 'Отсутствует':
        await call.message.edit_caption(
            caption=f"<b>❌ Ваша подписка - отсутствует</b>",
            parse_mode='HTML',
            reply_markup=await nehvataet_kb()
        )
    else:
        await call.message.edit_caption(
            caption=f"<b>💎 Выбери причину репорта</b>",
            parse_mode='HTML',
            reply_markup=await tltreport()
        )

@dp.callback_query_handler(lambda callback_query: callback_query.data.startswith("tlt"))
async def reasonswat(callback_query: types.CallbackQuery, state: FSMContext):
    user_id = callback_query.from_user.id
    issub = (await get_aktiv(user_id))[0]
    if issub == 'Отсутствует':
        await call.message.edit_caption(
            caption=f"<b>❌ Ваша подписка - отсутствует</b>",
            parse_mode='HTML',
            reply_markup=await nehvataet_kb()
        )
    else:
        reason = callback_query.data.split(":")[1]
        await state.set_state(repomessage.link)
        await state.update_data(reason_str=reason)
        await callback_query.message.edit_caption(
            "<b>🚀 Вы выбрали метод: Telethon\n💎 Введите ссылку на сообщение для репорта</b>",
            reply_markup=await cancelkb(), parse_mode='HTML'
        )

def is_valid_url(url: str) -> bool:
    url_pattern = re.compile(
        r"^(https?://)?" r"(([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,})" r"(:\d+)?" r"(/[^\s]*)?$"
    )
    return bool(url_pattern.match(url))

@dp.message_handler(state=repomessage.link)
async def misanthropic_division(message: types.Message, state: FSMContext):
    links = message.text.split(",")
    user_id = message.from_user.id
    reason_str = (await state.get_data())["reason_str"]
    if len(links) < 1:
        await state.finish()
        return await message.reply("<b>💎 Введите хотя бы одну ссылку</b>", reply_markup=await cancelkb(), parse_mode='HTML')

    for link in links:
        if not is_valid_url(link):
            await state.finish()
            return await message.reply(f"<b>❌ Ссылка {link} не валидная</b>", reply_markup=await cancelkb(), parse_mode='HTML')

    await state.finish()

    successful_reports = 0
    failed_reports = 0

    for message_link in links:
        if message_link.startswith("https://t.me/c/"):
            parts = message_link.split("/")
            chat_id = int(parts[4])

            try:
                chat = await bot.get_chat(chat_id)
                if chat.type == "private":
                    await message.reply("❌ <b>Чат приватный. Снос невозможен</b>", reply_markup=await cancelkb(), parse_mode='HTML')
                    return
            except Exception:
                await message.reply("❌ <b>Чат приватный. Снос невозможен</b>", reply_markup=await cancelkb(), parse_mode='HTML')
                return
        await bot.send_message(chat_id=user_id, text="<b>🚀 Отправляем репорты...</b>", parse_mode='HTML')
        successful, failed = await snos(user_id, message_link, reason_str)
        successful_reports += successful
        failed_reports += failed


    links_str = ' '.join(links)
    response_message = f"<b>💎 Жалобы отправлены</b>\n\n<b>⚙️ Метод:</b> <code>{reason_str.capitalize()}</code>\n<b>🔗 Ссылка:</b> <code>{links_str}</code>\n\n<b>👤 Репорты успешно отправлены</b>\n\n<b>✅ Успешно:</b> <code>{successful_reports}</code>\n<b>❌ Неуспешно:</b> <code>{failed_reports}</code>"

    await bot.send_message(chat_id=user_id, text="🚀")
    await bot.send_photo(
        chat_id=user_id,
        photo=photo,
        caption=response_message,
        parse_mode="HTML",
        reply_markup=await bbk()
    )

def filtersnos(message_url):
    path = message_url[len("https://t.me/") :].split("/")
    if len(path) == 2:
        chat_username = path[0]
        message_id = int(path[1])
        return chat_username, message_id
    raise ValueError("Неверная ссылка!")


async def snos(user_id, message_url, reason_str):
    chat_username, message_id = filtersnos(message_url)
    successful_reports = 0
    failed_reports = 0
    successful_sessions = []
    session_files = os.listdir("tltsessions/")
    device_models = ["iPhone 13", "Samsung Galaxy S21", "Google Pixel 6", "OnePlus 9"]
    app_versions = ["8.7.1", "9.3.4", "7.8.9", "8.6.2"]
    async def report_session(session):
        nonlocal successful_reports, failed_reports, successful_sessions

        if not session.endswith(".session"):
            return

        random_api = random.choice(API)
        api_id, api_hash = random_api.split(":")

        device_model = random.choice(device_models)
        app_version = random.choice(app_versions)
        client = TelegramClient(
            f"tltsessions/{session}", api_id, api_hash, auto_reconnect=True,
            device_model=device_model, app_version=app_version
        )

        try:
            await client.connect()

            if not await client.is_user_authorized():
                failed_reports += 1
                await client.disconnect()
                return

            reason = reasons.get(reason_str, InputReportReasonOther())

            await client(ReportRequest(
                peer=chat_username,
                id=[message_id],
                reason=reason,
                message="This user is engaged in telegram spam mailings. Take action",
            ))

            successful_reports += 1
            successful_sessions.append(session)


        except Exception as e:
            pass
            failed_reports += 1
        finally:
            await client.disconnect()

    tasks = []
    for session in session_files:
        if session.endswith(".session"):
            tasks.append(report_session(session))

    try:
        await asyncio.wait_for(asyncio.gather(*tasks), timeout=10)
    except asyncio.TimeoutError:
        await send_report(user_id, message_url, reason_str, successful_reports, failed_reports)
        return successful_reports, failed_reports

    await send_report(user_id, message_url, reason_str, successful_reports, failed_reports)
    return successful_reports, failed_reports


async def send_report(user_id, message_url, reason_str, successful_reports, failed_reports):
    if successful_reports > 0:
        user = await bot.get_chat(user_id)
        user_name = user.username if user.username else " "
        message_text = f"""<b>💎 Новый репорт</b>\n<b>👤 ID:</b> @{user_name} | {user_id}\n<b>🚀 Метод:</b> {reason_str.capitalize()}\n<b>💎 Ссылки:</b> <a href="{message_url}">Перейти</a>\n<b>✅ Жалобы успешно отправлены:</b> {successful_reports}\n<b>❌ Неуспешные репорты:</b> {failed_reports}
        """
        for z in admin:
            await bot.send_message(z, message_text, parse_mode="HTML")
    else:
        print("Не удалось отправить жалобу с ни одной сессии.")