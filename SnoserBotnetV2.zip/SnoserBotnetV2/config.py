bot_token = '8365548858:AAEbN_q9BEB4xrmf9aPx11rlcAj0x8c9BQI'
admin = [8299768278]
APIKEY = ''
cryptotoken = '492470:AA3meLbzLT1BBystK148Ji6DlkVAgAvPAWh'
login = 'AirBotnet'
secret = 'c31bfa3ce20ac99728b4efb55cf4ffbeea737f6e' # это не трогаешь 
photo = 'https://photos.google.com/photo/AF1QipOoxrdxeMbvkENRhcV3Q-sI0lZI_vJXZEnPjDvn'
API = [
    "24565698:5a084b434f8505ace703485b9da85040",
    "27904162:e7cba879b1c643ba77490bf328df5eab",
    "23037915:50f06f5b2223586fde0d1379ea91ebc7",
]
logs_id = -1002277003952# логи айди
channel1_id = -1003259505746
channel2_id = -1003117077473